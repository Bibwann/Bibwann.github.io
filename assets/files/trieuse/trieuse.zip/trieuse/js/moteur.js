import * as THREE from 'three';

// Constantes physiques de la simulation
// Résistance de l'air (ralentissement progressif)
const AIR_DRAG = 0.5;
// Constante de gravité (vers le bas sur l'axe Y)
export const GRAVITY = -9.81;

/**
 * Moteur physique personnalisé pour gérer les collisions et mouvements
 * dans la scène Three.js.
 */
export class PhysicsEngine {
    constructor() {
        // Vecteur de gravité appliqué à chaque étape
        this.gravity = new THREE.Vector3(0, GRAVITY, 0);
        
        // Liste des balles dynamiques dans la simulation
        this.balls = [];    
        
        // Liste des boîtes statiques (murs, sol, obstacles)
        this.boxes = [];    
        
        // --- Vecteurs temporaires pour les calculs ---
        // On les instancie ici pour éviter de créer des objets en boucle (Garbage Collection)
        // Vecteur générique de calcul
        this._tempVec = new THREE.Vector3();
        // Position locale de la balle par rapport à une boîte
        this._localPos = new THREE.Vector3();
        // Point le plus proche sur une boîte
        this._closest = new THREE.Vector3();
        // Normale de collision calculée
        this._normal = new THREE.Vector3();
    }

    /**
     * Ajoute une nouvelle balle à la simulation
     * @param {THREE.Mesh} mesh - Le mesh visuel de la balle
     * @param {number} radius - Le rayon de la sphère physique
     * @returns {Object} L'objet balle créé
     */
    addBall(mesh, radius) {
        // Création de l'objet physique "balle"
        const ball = {
            mesh: mesh,                       // Référence au visuel
            radius: radius,                   // Rayon de collision
            pos: mesh.position.clone(),       // Position physique (indépendante du mesh)
            vel: new THREE.Vector3(0, 0, 0),  // Vitesse initiale nulle
            friction: 1.0,                    // Coefficient de frottement
            bounciness: 0.2,                  // Rebondissement (restitution)
            counted: false,                   // Flag pour la logique de tri
            idx: -1                           // Index ou ID (si nécessaire)
        };
        this.balls.push(ball); // Ajout à la liste de mise à jour
        return ball;
    }

    /**
     * Ajoute un obstacle statique de type "Boîte"
     * @param {THREE.Vector3} position - Centre de la boîte
     * @param {THREE.Quaternion} quaternion - Rotation de la boîte
     * @param {THREE.Vector3} halfSize - Demi-tailles (x, y, z) de la boîte (extents)
     */
    addBox(position, quaternion, halfSize) {
        this.boxes.push({
            pos: position.clone(),            // Position du centre
            quat: quaternion.clone(),         // Rotation mondiale
            invQuat: quaternion.clone().invert(), // Rotation inverse (pour calculs locaux)
            halfSize: halfSize.clone()        // Dimensions pour les bornes de collision
        });
    }

    // Vide la liste des balles (pour redémarrer la simulation de tri)
    reset() { 
        this.balls = []; 
    }

    // NOUVEAU: Vide les murs/rails (pour le changement de scène complet)
    clearStatic() {
        this.boxes = [];
    }

    /**
     * Résout la collision entre une sphère (balle) et une boîte orientée (OBB)
     * @param {Object} ball - La balle
     * @param {Object} box - L'obstacle boîte
     * @returns {boolean} Vrai si collision détectée
     */
    resolveSphereBox(ball, box) {
        // 1. Convertir la position de la balle dans l'espace local de la boîte
        // On soustrait la position de la boîte et on applique la rotation inverse
        this._localPos.copy(ball.pos).sub(box.pos).applyQuaternion(box.invQuat);

        // 2. Trouver le point le plus proche sur la boîte (Clamping)
        // On limite la position locale aux dimensions de la boîte (halfSize)
        this._closest.copy(this._localPos).clamp(
            this._tempVec.copy(box.halfSize).negate(), // Min: -halfSize
            box.halfSize                               // Max: +halfSize
        );

        // 3. Calculer la distance entre le centre de la balle (local) et ce point proche
        const distVec = this._tempVec.copy(this._localPos).sub(this._closest);
        const distance = distVec.length();

        // 4. Si la distance est inférieure au rayon, il y a pénétration
        if (distance < ball.radius && distance > 0.00001) {
            // Calcul de la normale de collision (direction de la poussée)
            const normalLocal = distVec.normalize();
            // On repasse la normale dans l'espace Monde
            this._normal.copy(normalLocal).applyQuaternion(box.quat);

            // 5. Correction de position (Sortir la balle de la boîte)
            const overlap = ball.radius - distance;
            ball.pos.addScaledVector(this._normal, overlap);

            // 6. Réponse en vitesse (Rebond)
            const vDotN = ball.vel.dot(this._normal); // Vitesse le long de la normale
            if (vDotN < 0) { // Si on va vers le mur
                // Calcul de l'impulsion de rebond
                const j = -(1 + ball.bounciness) * vDotN;
                ball.vel.addScaledVector(this._normal, j);

                // Optionnel : Friction simple (ralentir le glissement)
                // On calcule la vitesse tangente en retirant la composante normale
                const tangent = this._tempVec.copy(ball.vel).sub(this._normal.clone().multiplyScalar(vDotN));
                ball.vel.sub(tangent.multiplyScalar(0.0001)); // Friction très légère
            }
            return true; // Collision traitée
        }
        return false; // Pas de collision
    }

    /**
     * Boucle principale de mise à jour physique
     * @param {number} dt - Temps écoulé depuis la dernière frame (delta time)
     * @param {number} subSteps - Nombre de sous-étapes pour la stabilité (précision)
     */
    step(dt, subSteps = 8) {
        // On divise le temps par le nombre de sous-étapes
        const stepDt = dt / subSteps;

        // On exécute la simulation plusieurs fois par frame pour éviter le "tunneling" (traverser des murs)
        for(let s=0; s<subSteps; s++) {
            
            // Pour chaque balle active
            for (let ball of this.balls) {
                
                // --- Intégration des forces ---
                
                // 1. Appliquer la gravité (vitesse augmente vers le bas)
                ball.vel.addScaledVector(this.gravity, stepDt);
                
                // 2. Appliquer la friction de l'air (amortissement)
                const damp = Math.max(0, 1 - AIR_DRAG * stepDt);
                ball.vel.multiplyScalar(damp);
                
                // 3. Mettre à jour la position (Intégration d'Euler)
                ball.pos.addScaledVector(ball.vel, stepDt);

                // --- Gestion des Collisions ---

                // 4. Collisions avec les murs/boîtes
                for (let box of this.boxes) {
                    this.resolveSphereBox(ball, box);
                }

                // 5. Collisions entre balles (Sphère contre Sphère)
                for (let other of this.balls) {
                    if (ball === other) continue; // Pas de collision avec soi-même

                    // Distance au carré (plus rapide pour vérifier le seuil)
                    const distSq = ball.pos.distanceToSquared(other.pos);
                    const radSum = ball.radius + other.radius;
                    
                    // Si la distance est inf à la somme des rayons => Contact
                    if (distSq < radSum * radSum) {
                        const dist = Math.sqrt(distSq);
                        
                        // Séparation des balles (on pousse chacune de moitié de l'interpénétration)
                        const overlap = radSum - dist;
                        this._normal.subVectors(ball.pos, other.pos).normalize();
                        
                        ball.pos.addScaledVector(this._normal, overlap * 0.5);
                        other.pos.addScaledVector(this._normal, -overlap * 0.5);

                        // Réponse élastique (échange d'impulsion)
                        const relVel = this._tempVec.subVectors(ball.vel, other.vel);
                        const velAlongNormal = relVel.dot(this._normal);
                        
                        // Seulement si elles se rapprochent
                        if (velAlongNormal < 0) {
                            const j = -(1 + 0.5) * velAlongNormal; // 0.5 restitution entre balles
                            ball.vel.addScaledVector(this._normal, j * 0.5);
                            other.vel.addScaledVector(this._normal, -j * 0.5);
                        }
                    }
                }

                // --- Mise à jour visuelle ---
                
                // Copie la position calculée vers l'objet Three.js visible
                ball.mesh.position.copy(ball.pos);
                
                // Simulation d'une rotation basée sur la vitesse (purement esthétique)
                // Donne l'impression que la balle roule
                ball.mesh.rotation.x += ball.vel.z * stepDt * 1.5; 
                ball.mesh.rotation.z -= ball.vel.x * stepDt * 1.5;
            }
        }
    }
}