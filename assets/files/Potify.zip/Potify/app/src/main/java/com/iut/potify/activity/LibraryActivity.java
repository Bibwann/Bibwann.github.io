package com.iut.potify.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.iut.potify.ressources.CsvLoader;
import com.iut.potify.ressources.Music;
import com.iut.potify.ressources.Playlist;
import com.iut.potify.ressources.MusicFilter;

import java.util.List;
import java.util.ArrayList;

import com.iut.potify.R;
import com.iut.potify.ressources.CsvLoader;
import com.iut.potify.ressources.Music;

public class LibraryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        ImageView navSearch = findViewById(R.id.nav_search);
        ImageView navFavorites = findViewById(R.id.nav_favorites);
        ImageView navLibrary = findViewById(R.id.nav_library);

        navSearch.setOnClickListener(v -> {
            Intent intent = new Intent(this, SearchActivity.class);
            startActivity(intent);
        });

        navFavorites.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });

        navLibrary.setOnClickListener(v -> {
            Intent intent = new Intent(this, BibliothequeActivity.class);
            startActivity(intent);
        });


    }

}
