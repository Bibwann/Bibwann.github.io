package com.iut.potify.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.iut.potify.R;
import com.iut.potify.ressources.CsvLoader;
import com.iut.potify.ressources.JsonStorage;
import com.iut.potify.ressources.Music;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

public class SearchActivity extends AppCompatActivity {

    private static final String TAG = "SearchActivity";

    private LinearLayout tableLayout;
    private EditText    searchBar;

    private List<Music> allMusics = new ArrayList<>();
    private List<String> likedTitles = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);

        tableLayout = findViewById(R.id.table_layout);
        searchBar   = findViewById(R.id.search_bar);

        loadAllMusics();

        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable s) {
                filterAndDisplay(s.toString());
            }
        });

        findViewById(R.id.nav_search).setOnClickListener(v -> {});
        findViewById(R.id.nav_favorites).setOnClickListener(v -> {
            startActivity(new Intent(SearchActivity.this, MainActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            finish();
        });
        findViewById(R.id.nav_library).setOnClickListener(v -> {
            startActivity(new Intent(SearchActivity.this, BibliothequeActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            finish();
        });
    }

    private void loadAllMusics() {
        Executors.newSingleThreadExecutor().execute(() -> {
            allMusics = CsvLoader.loadMusics(getApplicationContext());
            likedTitles = JsonStorage.loadLiked(getApplicationContext());
            for (Music m : allMusics) {
                m.setFavorite(likedTitles.contains(m.getTitle()));
            }
            runOnUiThread(() -> filterAndDisplay(searchBar.getText().toString()));
        });
    }

    private void filterAndDisplay(String query) {
        String lowerQ = query.toLowerCase().trim();
        if (lowerQ.isEmpty()) {
            displayList(allMusics);
            return;
        }
        List<Music> filtered = new ArrayList<>();
        for (Music m : allMusics) {
            if (m.getTitle().toLowerCase().contains(lowerQ)
                    || m.getArtist().toLowerCase().contains(lowerQ)) {
                filtered.add(m);
            }
        }
        displayList(filtered);
    }

    private void displayList(List<Music> musics) {
        tableLayout.removeAllViews();
        int index = 0;

        for (Music music : musics) {
            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
            itemLayout.setLayoutParams(params);
            itemLayout.setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12));
            itemLayout.setBackgroundColor(getResources().getColor(R.color.light_purple));
            itemLayout.setElevation(dpToPx(2));
            itemLayout.setClickable(true);
            itemLayout.setFocusable(true);

            // Pochette
            ImageView ivCover = new ImageView(this);
            LinearLayout.LayoutParams coverParams =
                    new LinearLayout.LayoutParams(dpToPx(64), dpToPx(64));
            ivCover.setLayoutParams(coverParams);
            ivCover.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Executors.newSingleThreadExecutor().execute(() -> {
                try {
                    InputStream in = new URL(music.getCoverUrl()).openStream();
                    Bitmap bmp = BitmapFactory.decodeStream(in);
                    runOnUiThread(() -> ivCover.setImageBitmap(bmp));
                } catch (Exception ignored) { }
            });
            itemLayout.addView(ivCover);

            // Titre + Artiste
            LinearLayout textLayout = new LinearLayout(this);
            textLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams textParams =
                    new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            textParams.setMargins(dpToPx(12), 0, 0, 0);
            textLayout.setLayoutParams(textParams);
            textLayout.setGravity(Gravity.CENTER_VERTICAL);

            TextView tvTitle = new TextView(this);
            tvTitle.setText(music.getTitle());
            tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            tvTitle.setTextColor(getResources().getColor(R.color.black));
            tvTitle.setTypeface(tvTitle.getTypeface(), android.graphics.Typeface.BOLD);
            textLayout.addView(tvTitle);

            TextView tvArtist = new TextView(this);
            tvArtist.setText(music.getArtist());
            tvArtist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            tvArtist.setTextColor(getResources().getColor(R.color.purple));
            textLayout.addView(tvArtist);

            itemLayout.addView(textLayout);

            // Icône étoile favorite
            ImageView ivFav = new ImageView(this);
            LinearLayout.LayoutParams favParams =
                    new LinearLayout.LayoutParams(dpToPx(40), dpToPx(40));
            favParams.setMargins(dpToPx(4), 0, dpToPx(4), 0);
            ivFav.setLayoutParams(favParams);
            ivFav.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            if (music.isFavorite()) {
                ivFav.setImageResource(R.drawable.star);
            } else {
                ivFav.setImageResource(R.drawable.w_star);
            }
            ivFav.setOnClickListener(v -> {
                boolean nouveauEtat = !music.isFavorite();
                if (nouveauEtat) {
                    // Ajout direct
                    music.setFavorite(true);
                    if (!likedTitles.contains(music.getTitle())) {
                        likedTitles.add(music.getTitle());
                    }
                    ivFav.setImageResource(R.drawable.star);
                    JsonStorage.save(SearchActivity.this, likedTitles, new ArrayList<>());
                } else {
                    // Confirmation avant de retirer
                    new AlertDialog.Builder(SearchActivity.this)
                            .setTitle("Supprimer des favoris")
                            .setMessage("Voulez-vous vraiment retirer \"" +
                                    music.getTitle() + "\" de vos favoris ?")
                            .setPositiveButton("Oui", (dialog, which) -> {
                                music.setFavorite(false);
                                likedTitles.remove(music.getTitle());
                                ivFav.setImageResource(R.drawable.w_star);
                                JsonStorage.save(SearchActivity.this, likedTitles, new ArrayList<>());
                            })
                            .setNegativeButton("Non", (dialog, which) -> {
                                music.setFavorite(true);
                                ivFav.setImageResource(R.drawable.star);
                            })
                            .show();
                }
            });
            itemLayout.addView(ivFav);

            // Icône playlist ("…")
            ImageView ivPlaylist = new ImageView(this);
            LinearLayout.LayoutParams plParams =
                    new LinearLayout.LayoutParams(dpToPx(40), dpToPx(40));
            plParams.setMargins(dpToPx(4), 0, 0, 0);
            ivPlaylist.setLayoutParams(plParams);
            ivPlaylist.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            ivPlaylist.setImageResource(R.drawable.library);
            ivPlaylist.setOnClickListener(v -> {
                String[] playlists = {"Titres favoris"};
                new AlertDialog.Builder(SearchActivity.this)
                        .setTitle("Ajouter à une playlist")
                        .setItems(playlists, (dialog, which) -> {
                            String choisie = playlists[which];
                            Log.d(TAG, "Ajout de \"" +
                                    music.getTitle() + "\" à \"" + choisie + "\"");
                        })
                        .setNegativeButton("Annuler", null)
                        .show();
            });
            itemLayout.addView(ivPlaylist);

            // Clic sur la ligne pour lancer MusicPlayerActivity
            final int indexToSend = index;
            itemLayout.setOnClickListener(v -> {
                Log.d(TAG, "Clique sur : " + music.getTitle());
                Intent intent = new Intent(SearchActivity.this, MusicPlayerActivity.class);
                ArrayList<String> titles    = new ArrayList<>();
                ArrayList<String> artists   = new ArrayList<>();
                ArrayList<String> covers    = new ArrayList<>();
                ArrayList<String> durations = new ArrayList<>();
                ArrayList<String> mp3urls   = new ArrayList<>();
                for (Music m : allMusics) {
                    titles.add(m.getTitle());
                    artists.add(m.getArtist());
                    covers.add(m.getCoverUrl());
                    durations.add(m.getDuration());
                    mp3urls.add(m.getMp3Url());
                }
                intent.putStringArrayListExtra(
                        MusicPlayerActivity.EXTRA_TITLES, titles);
                intent.putStringArrayListExtra(
                        MusicPlayerActivity.EXTRA_ARTISTS, artists);
                intent.putStringArrayListExtra(
                        MusicPlayerActivity.EXTRA_COVERS, covers);
                intent.putStringArrayListExtra(
                        MusicPlayerActivity.EXTRA_DURATIONS, durations);
                intent.putStringArrayListExtra(
                        MusicPlayerActivity.EXTRA_PLAYLIST, mp3urls);
                intent.putExtra(MusicPlayerActivity.EXTRA_INDEX, indexToSend);

                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_up, R.anim.none);
            });

            tableLayout.addView(itemLayout);
            index++;
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
