package com.iut.potify.ressources;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class JsonStorage {
    private static final String FILE_NAME = "data.json";

    public static void save(Context context, List<String> liked, List<String> history) {
        try {
            JSONObject root = readRoot(context);
            root.put("liked", new JSONArray(liked));
            root.put("history", new JSONArray(history));
            writeRoot(context, root);
        } catch (Exception e) {
            Log.e("JsonStorage", "Erreur de sauvegarde JSON", e);
        }
    }

    public static List<String> loadLiked(Context context) {
        return loadArray(context, "liked");
    }

    public static List<String> loadHistory(Context context) {
        return loadArray(context, "history");
    }

    private static List<String> loadArray(Context context, String key) {
        List<String> result = new ArrayList<>();
        try {
            JSONObject root = readRoot(context);
            JSONArray array = root.optJSONArray(key);
            if (array != null) {
                for (int i = 0; i < array.length(); i++) {
                    result.add(array.getString(i));
                }
            }
        } catch (Exception e) {
            Log.e("JsonStorage", "Erreur de lecture JSON", e);
        }
        return result;
    }

    // ────────────── PLAYLISTS MANAGEMENT ──────────────

    // Charge la liste des noms de playlists (hors "liked" et "history")
    public static List<String> loadPlaylists(Context context) {
        List<String> playlists = new ArrayList<>();
        try {
            JSONObject root = readRoot(context);
            JSONObject playlistsObj = root.optJSONObject("playlists");
            if (playlistsObj != null) {
                JSONArray names = playlistsObj.names();
                if (names != null) {
                    for (int i = 0; i < names.length(); i++) {
                        playlists.add(names.getString(i));
                    }
                }
            }
        } catch (Exception e) {
            Log.e("JsonStorage", "Erreur lors du chargement des playlists", e);
        }
        return playlists;
    }

    // Sauvegarde ou met à jour une playlist (nom + titres)
    public static void savePlaylist(Context context, String playlistName, List<String> titles) {
        try {
            JSONObject root = readRoot(context);
            JSONObject playlistsObj = root.optJSONObject("playlists");
            if (playlistsObj == null)
                playlistsObj = new JSONObject();
            playlistsObj.put(playlistName, new JSONArray(titles));
            root.put("playlists", playlistsObj);
            writeRoot(context, root);
        } catch (Exception e) {
            Log.e("JsonStorage", "Erreur lors de la sauvegarde d'une playlist", e);
        }
    }

    // Charge les titres d'une playlist
    public static List<String> loadPlaylistTitles(Context context, String playlistName) {
        List<String> titles = new ArrayList<>();
        try {
            JSONObject root = readRoot(context);
            JSONObject playlistsObj = root.optJSONObject("playlists");
            if (playlistsObj != null) {
                JSONArray array = playlistsObj.optJSONArray(playlistName);
                if (array != null) {
                    for (int i = 0; i < array.length(); i++) {
                        titles.add(array.getString(i));
                    }
                }
            }
        } catch (Exception e) {
            Log.e("JsonStorage", "Erreur lors de la lecture d'une playlist", e);
        }
        return titles;
    }

    // Supprime la playlist passée en paramètre
    public static void removePlaylist(Context context, String playlistName) {
        try {
            JSONObject root = readRoot(context);
            JSONObject playlistsObj = root.optJSONObject("playlists");
            if (playlistsObj != null && playlistsObj.has(playlistName)) {
                playlistsObj.remove(playlistName);
                root.put("playlists", playlistsObj);
                writeRoot(context, root);
                Log.d("JsonStorage", "Playlist supprimée : " + playlistName);
            } else {
                Log.d("JsonStorage", "Playlist NON trouvée pour suppression : " + playlistName);
            }
        } catch (Exception e) {
            Log.e("JsonStorage", "Erreur lors de la suppression de la playlist", e);
        }
    }

    // ────────────── UTILITAIRES INTERNE ──────────────

    // Lis l'objet JSON racine, le crée s'il n'existe pas et garantit "playlists"
    private static JSONObject readRoot(Context context) throws Exception {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    context.openFileInput(FILE_NAME)
            ));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
            }
            reader.close();
            JSONObject root = new JSONObject(builder.toString());
            // Force la clé playlists si absente
            if (!root.has("playlists")) root.put("playlists", new JSONObject());
            return root;
        } catch (FileNotFoundException e) {
            // Nouveau fichier
            JSONObject root = new JSONObject();
            root.put("liked", new JSONArray());
            root.put("history", new JSONArray());
            root.put("playlists", new JSONObject());
            return root;
        }
    }

    // Ecrit l'objet JSON racine
    private static void writeRoot(Context context, JSONObject root) throws Exception {
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE)
        ));
        writer.write(root.toString(2));
        writer.close();
    }
}
