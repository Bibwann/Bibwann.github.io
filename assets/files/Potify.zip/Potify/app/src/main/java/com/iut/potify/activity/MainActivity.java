package com.iut.potify.activity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.iut.potify.R;
import com.iut.potify.ressources.CsvLoader;
import com.iut.potify.ressources.JsonStorage;
import com.iut.potify.ressources.Music;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private LinearLayout tableLayout;
    private EditText    searchBar;

    private List<Music> allMusics;
    private List<String> likedTitles;
    private List<Music> favoriteMusics = new ArrayList<>();

    private ArrayList<String> favoriteTitles;
    private ArrayList<String> favoriteArtists;
    private ArrayList<String> favoriteCovers;
    private ArrayList<String> favoriteDurations;
    private ArrayList<String> favoriteMp3Urls;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1) Récupérer les vues
        tableLayout = findViewById(R.id.table_layout);
        searchBar   = findViewById(R.id.search_bar);

        // Si un exemple statique existe, on le supprime
        View example = findViewById(R.id.example_music);
        if (example != null) {
            tableLayout.removeView(example);
        }

        // 2) Charger les favoris puis afficher
        loadAndDisplayFavorites();

        // 3) Configurer la recherche en temps réel dans l’écran Favoris
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable s) {
                filterAndDisplay(s.toString().trim());
            }
        });

        // 4) Configurer les boutons de navigation en bas
        // – Lorsque l’utilisateur clique sur l’icône recherche, on démarre SearchActivity
        findViewById(R.id.nav_search).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SearchActivity.class);
            // Animation de transition (la Search « descend » depuis la droite)
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            finish();
        });

        // – Favoris (ici on est déjà dans l’écran Favoris → rien à faire)
        findViewById(R.id.nav_favorites).setOnClickListener(v -> {
            // On est déjà sur MainActivity (écran Favoris), donc rien à faire.
        });

        // – Bibliothèque (Playlist)
        findViewById(R.id.nav_library).setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, BibliothequeActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            finish();
        });
    }

    /**
     * Charge toutes les musiques depuis le CSV, récupère la liste des favoris,
     * remplit favoriteMusics + listes parallèles, puis affiche la liste.
     */
    private void loadAndDisplayFavorites() {
        Executors.newSingleThreadExecutor().execute(() -> {
            allMusics   = CsvLoader.loadMusics(getApplicationContext());
            likedTitles = JsonStorage.loadLiked(getApplicationContext());

            favoriteMusics.clear();
            favoriteTitles    = new ArrayList<>();
            favoriteArtists   = new ArrayList<>();
            favoriteCovers    = new ArrayList<>();
            favoriteDurations = new ArrayList<>();
            favoriteMp3Urls   = new ArrayList<>();

            for (Music m : allMusics) {
                if (likedTitles.contains(m.getTitle())) {
                    m.setFavorite(true);
                    favoriteMusics.add(m);
                    favoriteTitles.add(m.getTitle());
                    favoriteArtists.add(m.getArtist());
                    favoriteCovers.add(m.getCoverUrl());
                    favoriteDurations.add(m.getDuration());
                    favoriteMp3Urls.add(m.getMp3Url());
                }
            }
            runOnUiThread(() -> displayFromList(favoriteMusics));
        });
    }

    /**
     * Affiche dynamiquement la liste `list` (ici les favoris filtrés) dans `tableLayout`.
     */
    private void displayFromList(List<Music> list) {
        tableLayout.removeAllViews();

        int index = 0;
        for (Music music : list) {
            // Création ligne horizontale
            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
            itemLayout.setLayoutParams(params);
            itemLayout.setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12));
            itemLayout.setBackgroundColor(getResources().getColor(R.color.light_purple));
            itemLayout.setElevation(dpToPx(2));
            itemLayout.setClickable(true);
            itemLayout.setFocusable(true);

            // 1) Pochette (téléchargée asynchrone)
            ImageView ivCover = new ImageView(this);
            LinearLayout.LayoutParams coverParams = new LinearLayout.LayoutParams(dpToPx(64), dpToPx(64));
            ivCover.setLayoutParams(coverParams);
            ivCover.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Executors.newSingleThreadExecutor().execute(() -> {
                try {
                    InputStream in = new URL(music.getCoverUrl()).openStream();
                    Bitmap bmp = BitmapFactory.decodeStream(in);
                    runOnUiThread(() -> ivCover.setImageBitmap(bmp));
                } catch (Exception ignored) { }
            });
            itemLayout.addView(ivCover);

            // 2) Bloc Texte (titre + artiste)
            LinearLayout textLayout = new LinearLayout(this);
            textLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            );
            textParams.setMargins(dpToPx(12), 0, 0, 0);
            textLayout.setLayoutParams(textParams);
            textLayout.setGravity(Gravity.CENTER_VERTICAL);

            TextView tvTitle = new TextView(this);
            tvTitle.setText(music.getTitle());
            tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            tvTitle.setTextColor(getResources().getColor(R.color.black));
            tvTitle.setTypeface(tvTitle.getTypeface(), android.graphics.Typeface.BOLD);
            textLayout.addView(tvTitle);

            TextView tvArtist = new TextView(this);
            tvArtist.setText(music.getArtist());
            tvArtist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            tvArtist.setTextColor(getResources().getColor(R.color.purple));
            textLayout.addView(tvArtist);

            itemLayout.addView(textLayout);

            // 3) Icône étoile pleine – clic pour retirer des favoris
            ImageView ivFav = new ImageView(this);
            LinearLayout.LayoutParams favParams = new LinearLayout.LayoutParams(dpToPx(40), dpToPx(40));
            ivFav.setLayoutParams(favParams);
            ivFav.setImageResource(R.drawable.star);
            itemLayout.addView(ivFav);

            final int idx = index;
            ivFav.setOnClickListener(v -> {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Retirer des favoris")
                        .setMessage(
                                "Voulez-vous vraiment retirer \"" + music.getTitle() + "\" de vos favoris ?"
                        )
                        .setPositiveButton("Oui", (dialog, which) -> {
                            // Retrait du titre de la liste likedTitles
                            likedTitles.remove(music.getTitle());
                            JsonStorage.save(getApplicationContext(), likedTitles, new ArrayList<>());

                            // Retirer de la liste favoriteMusics et des listes parallèles
                            favoriteMusics.remove(idx);
                            favoriteTitles.remove(idx);
                            favoriteArtists.remove(idx);
                            favoriteCovers.remove(idx);
                            favoriteDurations.remove(idx);
                            favoriteMp3Urls.remove(idx);

                            // Re-filtrer en tenant compte du texte dans la barre de recherche
                            filterAndDisplay(searchBar.getText().toString().trim());
                        })
                        .setNegativeButton("Non", null)
                        .show();
            });

            // 4) Clic sur l’item lui-même → MusicPlayerActivity
            itemLayout.setOnClickListener(v -> {
                int originalIndex = favoriteMusics.indexOf(music);
                Log.d(TAG, "Clique sur favori : " + music.getTitle());
                Intent intent = new Intent(MainActivity.this, MusicPlayerActivity.class);
                intent.putStringArrayListExtra(
                        MusicPlayerActivity.EXTRA_TITLES,    favoriteTitles
                );
                intent.putStringArrayListExtra(
                        MusicPlayerActivity.EXTRA_ARTISTS,   favoriteArtists
                );
                intent.putStringArrayListExtra(
                        MusicPlayerActivity.EXTRA_COVERS,    favoriteCovers
                );
                intent.putStringArrayListExtra(
                        MusicPlayerActivity.EXTRA_DURATIONS, favoriteDurations
                );
                intent.putStringArrayListExtra(
                        MusicPlayerActivity.EXTRA_PLAYLIST,  favoriteMp3Urls
                );
                intent.putExtra(MusicPlayerActivity.EXTRA_INDEX, originalIndex);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_up, R.anim.none);
            });

            tableLayout.addView(itemLayout);
            index++;
        }
    }

    /**
     * Filtre la liste des favoris actuellement affichés selon `query`,
     * puis ré-affiche l’écran.
     */
    private void filterAndDisplay(String query) {
        if (query.isEmpty()) {
            displayFromList(favoriteMusics);
            return;
        }
        String lower = query.toLowerCase(Locale.ROOT);
        List<Music> filtered = new ArrayList<>();
        for (Music m : favoriteMusics) {
            if (m.getTitle().toLowerCase(Locale.ROOT).contains(lower)
                    || m.getArtist().toLowerCase(Locale.ROOT).contains(lower)) {
                filtered.add(m);
            }
        }
        displayFromList(filtered);
    }

    // Convertir dp en pixels
    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
