package com.iut.potify.ressources;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.iut.potify.R;

import java.util.ArrayList;
import java.util.List;

public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.PlaylistViewHolder> {

    private final List<Playlist> playlists;
    private List<Playlist> allPlaylists;
    private OnPlaylistClickListener listener;

    public PlaylistAdapter(List<Playlist> playlists, OnPlaylistClickListener listener) {
        this.playlists = new ArrayList<>(playlists);
        this.allPlaylists = new ArrayList<>(playlists);
        this.listener = listener;
    }
    public interface OnPlaylistClickListener {
        void onPlaylistClick(Playlist playlist);
    }

    @NonNull
    @Override
    public PlaylistViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_playlist, parent, false);
        return new PlaylistViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlaylistViewHolder holder, int position) {
        Playlist playlist = playlists.get(position);
        holder.title.setText(playlist.getName());
        holder.cover.setImageResource(playlist.getIconResId());
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onPlaylistClick(playlist);
        });
    }

    @Override
    public int getItemCount() {
        return playlists.size();
    }

    public static class PlaylistViewHolder extends RecyclerView.ViewHolder {
        ImageView cover;
        TextView title;

        public PlaylistViewHolder(@NonNull View itemView) {
            super(itemView);
            cover = itemView.findViewById(R.id.playlist_cover);
            title = itemView.findViewById(R.id.playlist_title);
        }
    }
    public void setPlaylists(List<Playlist> playlists) {
        this.allPlaylists = new ArrayList<>(playlists);
        filter(""); // affiche tout par défaut
    }
    public void filter(String query) {
        playlists.clear();
        if (query.isEmpty()) {
            playlists.addAll(allPlaylists);
        } else {
            for (Playlist p : allPlaylists) {
                if (p.getName().toLowerCase().contains(query.toLowerCase())) {
                    playlists.add(p);
                }
            }
        }
        notifyDataSetChanged();
    }
}
