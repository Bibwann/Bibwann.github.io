package com.iut.potify.ressources;

import java.util.ArrayList;
import java.util.List;

public class MusicFilter {

    /**
     * Filtre la liste de musiques pour ne conserver que celles
     * dont le titre contient la chaîne `query` (cas insensible).
     */
    public static List<Music> filterByTitle(List<Music> musics, String query) {
        List<Music> result = new ArrayList<>();
        if (query == null || query.isEmpty()) {
            return new ArrayList<>(musics);
        }
        String lowerQuery = query.toLowerCase();
        for (Music m : musics) {
            if (m.getTitle().toLowerCase().contains(lowerQuery)) {
                result.add(m);
            }
        }
        return result;
    }

    /**
     * Filtre la liste de musiques pour ne conserver que celles
     * dont l'artiste contient la chaîne `query` (cas insensible).
     */
    public static List<Music> filterByAuthor(List<Music> musics, String query) {
        List<Music> result = new ArrayList<>();
        if (query == null || query.isEmpty()) {
            return new ArrayList<>(musics);
        }
        String lowerQuery = query.toLowerCase();
        for (Music m : musics) {
            if (m.getArtist().toLowerCase().contains(lowerQuery)) {
                result.add(m);
            }
        }
        return result;
    }

    /**
     * Trie la liste de musiques en plaçant les plus notées en premier.
     * Ici, on considère que chaque Music possède un champ `note` (int).
     * Si tu n'utilises pas ce champ, tu peux adapter ou supprimer cette méthode.
     */
    public static List<Music> orderByNotation(List<Music> musics) {
        List<Music> result = new ArrayList<>(musics);
        result.sort((m1, m2) -> Integer.compare(m2.isFavorite() ? 1 : 0, m1.isFavorite() ? 1 : 0));
        // Si tu avais un champ `note` dans Music, remplacer l'expression ci-dessus par :
        // result.sort((m1, m2) -> Float.compare(m2.getNote(), m1.getNote()));
        return result;
    }

    /** Version d'appoint si tu as un objet Playlist contenant une liste de Music. */
    @SuppressWarnings("unused")
    public static List<Music> orderByNotation(Playlist playlist) {
        return orderByNotation(playlist.getMusics());
    }
}
