package com.iut.potify.ressources;

import android.content.Context;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class CsvLoader {
    public static List<Music> loadMusics(Context context) {
        List<Music> musics = new ArrayList<>();
        try {
            InputStream is = context.getAssets().open("lyrics.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));


            String firstLine = reader.readLine();
            if (firstLine != null && firstLine.startsWith("title#album#artist")) {

            } else if (firstLine != null) {
                parseLineIntoList(firstLine, musics);
            }

            String line;
            while ((line = reader.readLine()) != null) {
                parseLineIntoList(line, musics);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return musics;
    }

    private static void parseLineIntoList(String line, List<Music> musics) {
        String[] tokens = line.split("#");
        if (tokens.length >= 8) {
            String title = tokens[0];
            String album = tokens[1];
            String artist = tokens[2];
            String date = tokens[3];
            String cover = "http://edu.info06.net/lyrics/images/" + tokens[4];
            String contentLines = tokens[5];
            String mp3 = "http://edu.info06.net/lyrics/mp3/" + tokens[6];
            String duration = tokens[7];

            Music m = new Music(title, album, artist, date, cover, contentLines, mp3, duration);
            musics.add(m);
        }
    }
}
