package com.iut.potify.activity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.iut.potify.R;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.Executors;

public class MusicPlayerActivity extends AppCompatActivity {

    private static final String TAG = "MusicPlayerActivity";

    public static final String EXTRA_TITLES    = "extra_titles";
    public static final String EXTRA_ARTISTS   = "extra_artists";
    public static final String EXTRA_COVERS    = "extra_covers";
    public static final String EXTRA_DURATIONS = "extra_durations";
    public static final String EXTRA_PLAYLIST  = "extra_playlist";
    public static final String EXTRA_INDEX     = "extra_index";

    private ImageButton playPauseButton, prevButton, nextButton;
    private SeekBar seekBar;
    private TextView currentTimeView, totalTimeView, musicTitle, musicArtist;
    private ImageView musicCover;

    private MediaPlayer mediaPlayer;
    private Handler handler = new Handler();
    private Runnable updateSeekBar;
    private boolean isPrepared = false;

    // Toutes les listes reçues
    private ArrayList<String> titles;
    private ArrayList<String> artists;
    private ArrayList<String> covers;
    private ArrayList<String> durations;
    private ArrayList<String> playlist;
    private int currentIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music);

        // 1) Récupère les vues
        ImageButton backButton     = findViewById(R.id.back_button);
        musicCover                 = findViewById(R.id.music_cover);
        musicTitle                 = findViewById(R.id.music_title);
        musicArtist                = findViewById(R.id.music_artist);
        ImageButton favoriteButton = findViewById(R.id.favorite_button);
        seekBar                    = findViewById(R.id.seek_bar);
        currentTimeView            = findViewById(R.id.current_time);
        totalTimeView              = findViewById(R.id.total_time);
        playPauseButton            = findViewById(R.id.play_pause_button);
        prevButton                 = findViewById(R.id.previous_button);
        nextButton                 = findViewById(R.id.next_button);

        // 2) Récupère TOUTES les ArrayList transmises
        titles      = getIntent().getStringArrayListExtra(EXTRA_TITLES);
        artists     = getIntent().getStringArrayListExtra(EXTRA_ARTISTS);
        covers      = getIntent().getStringArrayListExtra(EXTRA_COVERS);
        durations   = getIntent().getStringArrayListExtra(EXTRA_DURATIONS);
        playlist    = getIntent().getStringArrayListExtra(EXTRA_PLAYLIST);
        currentIndex = getIntent().getIntExtra(EXTRA_INDEX, 0);

        Log.d(TAG, "Received index=" + currentIndex + ", playlist-size=" + (playlist != null ? playlist.size() : 0));

        // 3) Prépare l’UI (on met des valeurs “placeholder”, puis on met à jour rapidement dans updateMetadata())
        musicTitle.setText("");
        musicArtist.setText("");
        totalTimeView.setText(" / 0:00");
        currentTimeView.setText("0:00");
        playPauseButton.setImageResource(android.R.drawable.ic_media_play);
        seekBar.setMax(0);
        seekBar.setProgress(0);

        // 4) Retour (flèche bas) : arrête la lecture et ferme avec animation “slide_out_down”
        backButton.setOnClickListener(v -> {
            stopAndRelease();
            finish();
            overridePendingTransition(R.anim.none, R.anim.slide_out_down);
        });

        // 5) Étoile (exemple pour faire disparaître l’étoile)
        favoriteButton.setOnClickListener(v -> favoriteButton.setVisibility(View.INVISIBLE));

        // 6) Lecture initiale :
        updateMetadata(currentIndex);
        prepareAndStartMediaPlayer(); // démarre la musique courante

        // 7) Play/Pause
        playPauseButton.setOnClickListener(v -> {
            if (!isPrepared) return;
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
                playPauseButton.setImageResource(android.R.drawable.ic_media_play);
                handler.removeCallbacks(updateSeekBar);
            } else {
                mediaPlayer.start();
                playPauseButton.setImageResource(android.R.drawable.ic_media_pause);
                startSeekBarUpdater();
            }
        });

        // 8) Précédent : décrémente l’index dans la liste (avec rebouclage)
        prevButton.setOnClickListener(v -> {
            if (playlist == null || playlist.isEmpty()) return;
            stopAndRelease();
            currentIndex = (currentIndex - 1 < 0) ? (playlist.size() - 1) : (currentIndex - 1);
            updateMetadata(currentIndex);
            prepareAndStartMediaPlayer();
        });

        // 9) Suivant : incrémente l’index (avec rebouclage)
        nextButton.setOnClickListener(v -> {
            if (playlist == null || playlist.isEmpty()) return;
            stopAndRelease();
            currentIndex = (currentIndex + 1 >= playlist.size()) ? 0 : (currentIndex + 1);
            updateMetadata(currentIndex);
            prepareAndStartMediaPlayer();
        });

        // 10) SeekBar : interaction utilisateur
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int prog, boolean fromUser) {
                if (fromUser && isPrepared) {
                    mediaPlayer.seekTo(prog);
                    currentTimeView.setText(formatTime(prog));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {
                handler.removeCallbacks(updateSeekBar);
            }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                if (mediaPlayer.isPlaying()) startSeekBarUpdater();
            }
        });
    }

    /** Met à jour TOUTES les vues (titre, artiste, durée, pochette) pour l’index donné. */
    private void updateMetadata(int index) {
        // 1) Titre / Artiste / Durée
        String t = titles.get(index);
        String a = artists.get(index);
        String d = durations.get(index);
        musicTitle.setText(t);
        musicArtist.setText(a);
        totalTimeView.setText(" / " + d);
        currentTimeView.setText("0:00");
        seekBar.setProgress(0);
        seekBar.setMax(0);

        // 2) Pochette (asynchrone)
        String coverUrl = covers.get(index);
        if (coverUrl != null && !coverUrl.isEmpty()) {
            Executors.newSingleThreadExecutor().execute(() -> {
                try {
                    InputStream in = new URL(coverUrl).openStream();
                    Bitmap bmp = BitmapFactory.decodeStream(in);
                    runOnUiThread(() -> musicCover.setImageBitmap(bmp));
                } catch (Exception e) {
                    Log.e(TAG, "Erreur chargement pochette index=" + index, e);
                }
            });
        }
    }

    /** Instancie MediaPlayer pour l’URL courante et démarre la lecture, sans double-anim. */
    private void prepareAndStartMediaPlayer() {
        String mp3Url = playlist.get(currentIndex);
        Log.d(TAG, "Préparation de l’URL = " + mp3Url);

        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(mp3Url);

            mediaPlayer.setOnPreparedListener(mp -> {
                isPrepared = true;
                int totalMillis = mp.getDuration();
                seekBar.setMax(totalMillis);
                mp.start();
                playPauseButton.setImageResource(android.R.drawable.ic_media_pause);
                startSeekBarUpdater();
            });

            mediaPlayer.setOnCompletionListener(mp -> {
                playPauseButton.setImageResource(android.R.drawable.ic_media_play);
                handler.removeCallbacks(updateSeekBar);
                mediaPlayer.seekTo(0);
                seekBar.setProgress(0);
                currentTimeView.setText("0:00");
                isPrepared = false;
            });

            mediaPlayer.prepareAsync();
        } catch (Exception e) {
            Log.e(TAG, "Erreur préparation MediaPlayer", e);
        }
    }

    /** Mets à jour toutes les 500ms la SeekBar et le texte du temps courant. */
    private void startSeekBarUpdater() {
        updateSeekBar = new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null && isPrepared && mediaPlayer.isPlaying()) {
                    int pos = mediaPlayer.getCurrentPosition();
                    seekBar.setProgress(pos);
                    currentTimeView.setText(formatTime(pos));
                    handler.postDelayed(this, 500);
                }
            }
        };
        handler.post(updateSeekBar);
    }

    private String formatTime(int millis) {
        int sec = millis / 1000;
        int min = sec / 60;
        sec = sec % 60;
        return String.format("%d:%02d", min, sec);
    }

    private void stopAndRelease() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        handler.removeCallbacks(updateSeekBar);
        isPrepared = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopAndRelease();
    }
}
