package com.iut.potify.ressources;

import androidx.annotation.NonNull;

public class Music {
    private String title;
    private String album;
    private String artist;
    private String date;
    private String coverUrl;
    private String contentLines;
    private String mp3Url;
    private String duration;
    private boolean isFavorite;

    public Music(String title, String album, String artist, String date,
                 String coverUrl, String contentLines, String mp3Url, String duration) {
        this.title = title;
        this.album = album;
        this.artist = artist;
        this.date = date;
        this.coverUrl = coverUrl;
        this.contentLines = contentLines;
        this.mp3Url = mp3Url;
        this.duration = duration;
        this.isFavorite = false;
    }

    public String getTitle() {
        return title;
    }

    public String getAlbum() {
        return album;
    }

    public String getArtist() {
        return artist;
    }

    public String getDate() {
        return date;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public String getContentLines() {
        return contentLines;
    }

    public String getMp3Url() {
        return mp3Url;
    }

    public String getDuration() {
        return duration;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean favorite) {
        isFavorite = favorite;
    }

    @NonNull
    @Override
    public String toString() {
        return title + " - " + artist + (isFavorite ? " ★" : "");
    }
}
