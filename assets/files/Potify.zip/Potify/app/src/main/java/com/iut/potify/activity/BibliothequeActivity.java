package com.iut.potify.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.iut.potify.R;
import com.iut.potify.ressources.PlaylistAdapter;
import com.iut.potify.ressources.Playlist;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class BibliothequeActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private PlaylistAdapter adapter;
    private List<Playlist> playlists = new ArrayList<>();
    private EditText searchBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bibliotheque);

        // 1. Initialisation des playlists
        playlists = new ArrayList<>();
        playlists.add(new Playlist("Titres favoris", R.drawable.w_star)); // Playlist spéciale
        playlists.addAll(loadPlaylists());
        // 2. Adapter AVEC le listener (ne pas refaire après)
        adapter = new PlaylistAdapter(playlists, playlist -> {
            Log.d("DEBUG", "Playlist click: " + playlist.getName());
            Intent intent = new Intent(this, PlaylistActivity.class);
            intent.putExtra("playlist_name", playlist.getName());
            startActivity(intent);
        });

        // 3. Setup navigation bar (bottom)
        setupNavigation();

        // 4. Setup RecyclerView
        recyclerView = findViewById(R.id.playlistRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        recyclerView.setAdapter(adapter);

        // 5. Bouton d’ajout de playlist
        ImageButton fab = findViewById(R.id.fab_add_playlist);
        fab.setOnClickListener(v -> showAddPlaylistDialog());

        // 6. Barre de recherche (filtrage dynamique)
        searchBar = findViewById(R.id.search_bar);
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.filter(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        playlists = new ArrayList<>();
        playlists.add(new Playlist("Titres favoris", R.drawable.w_star)); // Playlist spéciale
        playlists.addAll(loadPlaylists());
        adapter.setPlaylists(playlists);
        adapter.filter(searchBar.getText().toString());
    }

    // Navigation bar logic (change activity when clicking icons)
    private void setupNavigation() {
        ImageView navSearch = findViewById(R.id.nav_search);
        ImageView navFavorites = findViewById(R.id.nav_favorites);
        ImageView navLibrary = findViewById(R.id.nav_library);

        navSearch.setOnClickListener(v -> {
            Intent intent = new Intent(this, SearchActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            finish();
        });

        navFavorites.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class); // Mets ici ton activity "favoris"
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            finish();
        });

        navLibrary.setOnClickListener(v -> {
            // On reste sur la page bibliothèque, donc tu peux soit ne rien faire, soit refresh, soit disable ce bouton
        });
    }

    // Ajoute une nouvelle playlist
    private void showAddPlaylistDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Nouvelle playlist");
        final EditText input = new EditText(this);
        input.setHint("Nom de la playlist");
        builder.setView(input);

        builder.setPositiveButton("Ajouter", (dialog, which) -> {
            String name = input.getText().toString().trim();
            if (!name.isEmpty()) {
                Playlist nouvellePlaylist = new Playlist(name, R.drawable.library); // icône générique
                playlists.add(nouvellePlaylist);
                adapter.setPlaylists(playlists); // met à jour la liste complète
                adapter.filter(searchBar.getText().toString()); // remet le filtre courant
                savePlaylists(playlists);
            }
        });

        builder.setNegativeButton("Annuler", (dialog, which) -> dialog.cancel());
        builder.show();
    }
    private void savePlaylists(List<Playlist> playlists) {
        // On ignore la playlist "Titres favoris" (toujours présente)
        JSONArray arr = new JSONArray();
        for (Playlist p : playlists) {
            if (!"Titres favoris".equals(p.getName()))
                arr.put(p.getName());
        }
        getSharedPreferences("bibliotheque", MODE_PRIVATE)
                .edit()
                .putString("playlists", arr.toString())
                .apply();
    }

    private List<Playlist> loadPlaylists() {
        List<Playlist> res = new ArrayList<>();
        String data = getSharedPreferences("bibliotheque", MODE_PRIVATE)
                .getString("playlists", null);
        if (data != null) {
            try {
                JSONArray arr = new JSONArray(data);
                for (int i = 0; i < arr.length(); i++) {
                    res.add(new Playlist(arr.getString(i), R.drawable.library));
                }
            } catch (Exception ignored) { }
        }
        return res;
    }

}
