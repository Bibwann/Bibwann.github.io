package com.iut.potify.ressources;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.iut.potify.R;

import java.io.InputStream;
import java.net.URL;
import java.util.List;
import java.util.concurrent.Executors;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.ViewHolder> {

    private final List<Music> musics;

    public MusicAdapter(List<Music> musics) {
        this.musics = musics;
    }

    @NonNull
    @Override
    public MusicAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_music, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MusicAdapter.ViewHolder holder, int position) {
        Music music = musics.get(position);
        holder.title.setText(music.getTitle());
        holder.artist.setText(music.getArtist());
        holder.duration.setText(music.getDuration());

        // Téléchargement et affichage de la pochette en arrière-plan
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                InputStream in = new URL(music.getCoverUrl()).openStream();
                Bitmap bmp = BitmapFactory.decodeStream(in);
                new Handler(Looper.getMainLooper()).post(() -> holder.cover.setImageBitmap(bmp));
            } catch (Exception ignored) { }
        });

        // Affiche l'étoile si c'est un favori
        if (music.isFavorite()) {
            holder.fav.setVisibility(View.VISIBLE);
        } else {
            holder.fav.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return musics.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView cover, fav;
        TextView title, artist, duration;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            cover = itemView.findViewById(R.id.item_cover);
            fav = itemView.findViewById(R.id.item_fav);
            title = itemView.findViewById(R.id.item_title);
            artist = itemView.findViewById(R.id.item_artist);
            duration = itemView.findViewById(R.id.item_duration);
        }
    }
}
