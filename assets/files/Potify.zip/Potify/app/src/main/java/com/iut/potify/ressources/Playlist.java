package com.iut.potify.ressources;

import java.util.ArrayList;
import java.util.List;

public class Playlist {
    private final String name;
    private final int iconResId; // ressource drawable
    private List<Music> musics;

    public Playlist(String name, int iconResId) {
        this.name = name;
        this.iconResId = iconResId;
        this.musics = new ArrayList<Music>();
    }

    public String getName() {
        return name;
    }

    public int getIconResId() {
        return iconResId;
    }

    public List<Music> getMusics() {
        return musics;
    }
}
