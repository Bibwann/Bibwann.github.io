package com.iut.potify.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.util.TypedValue;

import androidx.appcompat.app.AppCompatActivity;

import com.iut.potify.R;
import com.iut.potify.ressources.CsvLoader;
import com.iut.potify.ressources.JsonStorage;
import com.iut.potify.ressources.Music;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

public class PlaylistActivity extends AppCompatActivity {

    public static final String EXTRA_PLAYLIST_NAME = "EXTRA_PLAYLIST_NAME";

    private ImageView    ivCover;
    private TextView     tvTitle, tvOwner;
    private ImageButton  btnPlayAll, btnPlaylistOptions;
    private LinearLayout trackListContainer;

    // Liste des Music à afficher
    private List<Music> playlistMusics = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.playlist);

        ivCover            = findViewById(R.id.playlist_cover);
        tvTitle            = findViewById(R.id.playlist_title);
        tvOwner            = findViewById(R.id.playlist_owner);
        btnPlayAll         = findViewById(R.id.btn_play_all);
        btnPlaylistOptions = findViewById(R.id.btn_playlist_options);
        trackListContainer = findViewById(R.id.track_list);

        // Récupérer le nom exact depuis l’intent !
        String playlistName = getIntent().getStringExtra("playlist_name");
        if (playlistName == null) {
            playlistName = "Playlist inconnue";
        }
        Log.d("PlaylistName", "Playlist affichée: " + playlistName);

        if ("Titres favoris".equalsIgnoreCase(playlistName)) {
            ivCover.setImageResource(R.drawable.w_star);
        }

        tvTitle.setText(playlistName);
        tvOwner.setText("By You");

        loadPlaylistContents(playlistName);

        btnPlayAll.setOnClickListener(v -> {
            if (playlistMusics.isEmpty()) return;
            Intent intent = new Intent(PlaylistActivity.this, MusicPlayerActivity.class);

            ArrayList<String> titles    = new ArrayList<>();
            ArrayList<String> artists   = new ArrayList<>();
            ArrayList<String> covers    = new ArrayList<>();
            ArrayList<String> durations = new ArrayList<>();
            ArrayList<String> mp3urls   = new ArrayList<>();

            for (Music m : playlistMusics) {
                titles.add(m.getTitle());
                artists.add(m.getArtist());
                covers.add(m.getCoverUrl());
                durations.add(m.getDuration());
                mp3urls.add(m.getMp3Url());
            }

            intent.putStringArrayListExtra(MusicPlayerActivity.EXTRA_TITLES,    titles);
            intent.putStringArrayListExtra(MusicPlayerActivity.EXTRA_ARTISTS,   artists);
            intent.putStringArrayListExtra(MusicPlayerActivity.EXTRA_COVERS,    covers);
            intent.putStringArrayListExtra(MusicPlayerActivity.EXTRA_DURATIONS, durations);
            intent.putStringArrayListExtra(MusicPlayerActivity.EXTRA_PLAYLIST,  mp3urls);
            intent.putExtra(MusicPlayerActivity.EXTRA_INDEX, 0);

            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.none);
        });

        // Gestion du bouton ...
        String finalPlaylistName = playlistName;
        btnPlaylistOptions.setOnClickListener(v -> {
            String[] options = {"Supprimer la playlist"};
            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Options de la playlist")
                    .setItems(options, (dialog, which) -> {
                        if (which == 0) {
                            new androidx.appcompat.app.AlertDialog.Builder(this)
                                    .setTitle("Supprimer la playlist")
                                    .setMessage("Voulez-vous vraiment supprimer cette playlist ?")
                                    .setPositiveButton("Oui", (d, w) -> {
                                        Log.d("PlaylistRemove", "Suppression demandée de : " + finalPlaylistName);
                                        supprimerPlaylist(finalPlaylistName);
                                        startActivity(new Intent(this, BibliothequeActivity.class));
                                        finish();
                                    })
                                    .setNegativeButton("Non", null)
                                    .show();
                        }
                    })
                    .setNegativeButton("Annuler", null)
                    .show();
        });

        // ► NAVIGATION BAS (icônes Recherche / Favoris / Bibliothèque)
        findViewById(R.id.nav_search).setOnClickListener(v -> {
            Intent intent = new Intent(PlaylistActivity.this, SearchActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            finish();
        });
        findViewById(R.id.nav_favorites).setOnClickListener(v -> {
            Intent intent = new Intent(PlaylistActivity.this, MainActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            finish();
        });
        findViewById(R.id.nav_library).setOnClickListener(v -> {
            Intent intent = new Intent(PlaylistActivity.this, BibliothequeActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_down);
            finish();
        });
    }

    private void loadPlaylistContents(String playlistName) {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Music> all = CsvLoader.loadMusics(getApplicationContext());
            playlistMusics.clear();

            if ("Titres favoris".equalsIgnoreCase(playlistName)) {
                List<String> likedTitles = JsonStorage.loadLiked(getApplicationContext());
                for (Music m : all) {
                    if (likedTitles.contains(m.getTitle())) {
                        m.setFavorite(true);
                        playlistMusics.add(m);
                    }
                }
            } else {
                List<String> trackTitles = JsonStorage.loadPlaylistTitles(getApplicationContext(), playlistName);
                for (String title : trackTitles) {
                    for (Music m : all) {
                        if (m.getTitle().equals(title)) {
                            playlistMusics.add(m);
                            break;
                        }
                    }
                }
            }

            runOnUiThread(() -> populatePlaylistUI(playlistName));
        });
    }

    private void populatePlaylistUI(String playlistName) {
        int count = playlistMusics.size();
        tvOwner.setText("By You • " + count + (count > 1 ? " songs" : " song"));

        if (!playlistMusics.isEmpty()) {
            String firstCoverUrl = playlistMusics.get(0).getCoverUrl();
            Executors.newSingleThreadExecutor().execute(() -> {
                try {
                    InputStream in = new URL(firstCoverUrl).openStream();
                    Bitmap bmp = BitmapFactory.decodeStream(in);
                    runOnUiThread(() -> ivCover.setImageBitmap(bmp));
                } catch (Exception ignored) { }
            });
        }

        trackListContainer.removeAllViews();
        int index = 1;
        for (Music m : playlistMusics) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            rp.setMargins(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
            row.setLayoutParams(rp);
            row.setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8));
            row.setBackgroundColor(getResources().getColor(R.color.light_purple));
            row.setElevation(dpToPx(2));
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView tvNum = new TextView(this);
            tvNum.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(24), ViewGroup.LayoutParams.WRAP_CONTENT));
            tvNum.setText(String.valueOf(index++));
            tvNum.setGravity(Gravity.CENTER);
            tvNum.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            row.addView(tvNum);

            LinearLayout textBlock = new LinearLayout(this);
            textBlock.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams tbp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            );
            tbp.setMargins(dpToPx(12), 0, 0, 0);
            textBlock.setLayoutParams(tbp);

            TextView tvSong = new TextView(this);
            tvSong.setText(m.getTitle());
            tvSong.setTextColor(getResources().getColor(R.color.black));
            tvSong.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            tvSong.setTypeface(tvSong.getTypeface(), android.graphics.Typeface.BOLD);
            textBlock.addView(tvSong);

            TextView tvArtist = new TextView(this);
            tvArtist.setText(m.getArtist());
            tvArtist.setTextColor(getResources().getColor(R.color.dark_gray));
            tvArtist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            textBlock.addView(tvArtist);

            row.addView(textBlock);

            TextView tvDur = new TextView(this);
            tvDur.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(48), ViewGroup.LayoutParams.WRAP_CONTENT));
            tvDur.setText(m.getDuration());
            tvDur.setGravity(Gravity.END);
            tvDur.setTextColor(getResources().getColor(R.color.black));
            tvDur.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            row.addView(tvDur);

            final int playIndex = index - 2;
            row.setOnClickListener(v -> {
                Intent intent = new Intent(PlaylistActivity.this, MusicPlayerActivity.class);
                ArrayList<String> titles    = new ArrayList<>();
                ArrayList<String> artists   = new ArrayList<>();
                ArrayList<String> covers    = new ArrayList<>();
                ArrayList<String> durations = new ArrayList<>();
                ArrayList<String> mp3urls   = new ArrayList<>();
                for (Music track : playlistMusics) {
                    titles.add(track.getTitle());
                    artists.add(track.getArtist());
                    covers.add(track.getCoverUrl());
                    durations.add(track.getDuration());
                    mp3urls.add(track.getMp3Url());
                }
                intent.putStringArrayListExtra(MusicPlayerActivity.EXTRA_TITLES,    titles);
                intent.putStringArrayListExtra(MusicPlayerActivity.EXTRA_ARTISTS,   artists);
                intent.putStringArrayListExtra(MusicPlayerActivity.EXTRA_COVERS,    covers);
                intent.putStringArrayListExtra(MusicPlayerActivity.EXTRA_DURATIONS, durations);
                intent.putStringArrayListExtra(MusicPlayerActivity.EXTRA_PLAYLIST,  mp3urls);
                intent.putExtra(MusicPlayerActivity.EXTRA_INDEX, playIndex);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_up, R.anim.none);
            });

            trackListContainer.addView(row);
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private void supprimerPlaylist(String playlistName) {
        // Supprime la playlist du stockage JSON
        JsonStorage.removePlaylist(this, playlistName);
        // Supprime la playlist du SharedPreferences de la bibliothèque
        removePlaylistFromPreferences(playlistName);
    }

    private void removePlaylistFromPreferences(String playlistName) {
        try {
            String key = "playlists";
            String data = getSharedPreferences("bibliotheque", MODE_PRIVATE)
                    .getString(key, null);
            if (data != null) {
                org.json.JSONArray arr = new org.json.JSONArray(data);
                org.json.JSONArray out = new org.json.JSONArray();
                for (int i = 0; i < arr.length(); i++) {
                    String name = arr.getString(i);
                    if (!name.equals(playlistName)) {
                        out.put(name);
                    }
                }
                getSharedPreferences("bibliotheque", MODE_PRIVATE)
                        .edit()
                        .putString(key, out.toString())
                        .apply();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
