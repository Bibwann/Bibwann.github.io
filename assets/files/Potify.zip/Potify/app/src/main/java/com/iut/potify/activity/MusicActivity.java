package com.iut.potify.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.iut.potify.ressources.CsvLoader;
import com.iut.potify.ressources.Music;
import com.iut.potify.ressources.Playlist;
import com.iut.potify.ressources.MusicFilter;

import java.util.List;
import java.util.ArrayList;

import com.iut.potify.R;
import com.iut.potify.ressources.CsvLoader;
import com.iut.potify.ressources.Music;

public class MusicActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

    }
}
